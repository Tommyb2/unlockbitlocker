@echo off
title BitLocker Administrator Pro - Installer & Launcher
color 0B
echo ==========================================================
echo       BITLOCKER ADMINISTRATOR PRO - WINDOWS INSTALLER     
echo ==========================================================
echo.

:: Cek Administrator Privileges
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [PERINGATAN] Script ini sebaiknya dijalankan sebagai Administrator.
    echo Klik kanan file ini lalu pilih 'Run as administrator'.
    echo.
)

where dotnet >nul 2>&1
if %errorLevel% neq 0 (
    echo [INFO] .NET 8 SDK belum terpasang.
    echo Membuka link download resmi Microsoft .NET 8 Desktop Runtime...
    start https://dotnet.microsoft.com/en-us/download/dotnet/8.0
    echo.
    echo Setelah menginstal .NET 8, jalankan kembali file ini.
    pause
    exit /b
)

echo [1/2] Mengompilasi aplikasi BitLocker Administrator Pro (.NET 8)...
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o "%~dp0publish"

if %errorLevel% equ 0 (
    echo.
    echo [2/2] Membuat Shortcut di Desktop Windows...
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Shortcut.ps1"
    
    echo.
    echo ==========================================================
    echo  INSTALASI SELESAI!
    echo  File .EXE: %~dp0publish\BitLockerAdminPro.exe
    echo  Shortcut telah dibuat di Desktop Windows Anda.
    echo ==========================================================
    echo.
    set /p launch="Apakah Anda ingin langsung menjalankan aplikasi sekarang? (Y/N): "
    if /i "%launch%"=="Y" (
        start "" "%~dp0publish\BitLockerAdminPro.exe"
    )
) else (
    echo.
    echo [ERROR] Gagal mengompilasi. Pastikan .NET 8 SDK terpasang dengan benar.
)
pause