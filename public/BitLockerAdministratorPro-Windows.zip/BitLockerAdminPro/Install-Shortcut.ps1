# Script PowerShell untuk membuat Shortcut Desktop dengan hak Administrator
$WshShell = New-Object -ComObject WScript.Shell
$DesktopPath = [System.Environment]::GetFolderPath('Desktop')
$TargetPath = Join-Path $PSScriptRoot "publish\BitLockerAdminPro.exe"

if (Test-Path $TargetPath) {
    $ShortcutPath = Join-Path $DesktopPath "BitLocker Administrator Pro.lnk"
    $Shortcut = $WshShell.CreateShortcut($ShortcutPath)
    $Shortcut.TargetPath = $TargetPath
    $Shortcut.WorkingDirectory = (Split-Path $TargetPath)
    $Shortcut.Description = "BitLocker Administrator Pro - Windows Storage Security Suite"
    $Shortcut.Save()
    Write-Host "[OK] Shortcut berhasil dibuat di Desktop: $ShortcutPath" -ForegroundColor Green
} else {
    Write-Host "[INFO] File executable belum dibangun. Jalankan build.bat terlebih dahulu." -ForegroundColor Yellow
}