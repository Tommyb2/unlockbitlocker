# BitLocker Administrator Pro

Aplikasi Windows Desktop profesional berbasis **C# .NET 8 WPF** untuk mengelola, membuka kunci, menonaktifkan enkripsi, dan memantau status BitLocker pada penyimpanan internal (SSD/HDD) dan eksternal (Flashdisk USB, Portable SSD, Hardisk Eksternal).

---

## 📋 Fitur Utama
1. **Deteksi Perangkat Otomatis**: Mendeteksi Flashdisk USB, SSD Eksternal, HDD Eksternal, dan drive internal dengan kapasitas, jenis perangkat, dan status BitLocker.
2. **Unlock BitLocker**: Mendukung Password maupun 48-digit Recovery Key secara aman melalui `manage-bde.exe`.
3. **Disable BitLocker (Dekripsi)**: Mematikan enkripsi dan mendekripsi volume resmi Windows dengan pemantauan persentase real-time.
4. **Pause & Resume**: Kemampuan menjeda dan melanjutkan proses dekripsi jika didukung volume.
5. **Keamanan Administrator**: Dilengkapi `app.manifest` dengan hak akses UAC `requireAdministrator`.
6. **Dark Mode Windows 11**: Tampilan modern dengan palet warna hitam, biru, hijau, dan merah.

---

## 🛠️ Persyaratan Sistem
- Sistem Operasi: Windows 10 (1809+) atau Windows 11 (64-bit).
- Hak Akses: Administrator Lokal (UAC Elevated).
- Runtime: .NET 8 Desktop Runtime (jika menjalankan build framework-dependent) atau gunakan build self-contained (tidak memerlukan instalasi .NET terpisah).

---

## 🚀 Petunjuk Build & Compile

### Cara 1: Menggunakan Script Otomatis (build.bat)
1. Buka folder proyek di Windows.
2. Klik kanan file `build.bat` lalu pilih **Run as Administrator** (atau jalankan di Command Prompt).
3. Script akan otomatis memanggil `dotnet publish` dan menghasilkan file:
   `publish\BitLockerAdminPro.exe` (Single-file standalone tanpa dependensi luar).

### Cara 2: Menggunakan Visual Studio 2022
1. Buka file `BitLockerAdminPro.csproj` di Visual Studio 2022 (v17.8 atau lebih baru).
2. Pastikan workload **.NET Desktop Development** terpasang.
3. Pilih konfigurasi **Release** dan target **x64**.
4. Klik kanan project `BitLockerAdminPro` -> **Publish...** -> Folder -> Publish.

### Cara 3: Menggunakan .NET CLI Terminal
```bash
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o ./publish
```

---

## 🔒 Keamanan Data
- Aplikasi ini **TIDAK PERNAH** memformat atau menghapus data pengguna.
- Aplikasi ini **TIDAK** membobol sandi; semua proses menggunakan API dan utilitas resmi Windows (`manage-bde.exe`).
- Selalu konfirmasi sebelum memulai dekripsi dan pastikan drive tetap terhubung hingga progres mencapai 100%.