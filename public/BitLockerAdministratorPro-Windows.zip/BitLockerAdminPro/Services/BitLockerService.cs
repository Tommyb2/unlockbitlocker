using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using BitLockerAdminPro.Models;

namespace BitLockerAdminPro.Services
{
    public class BitLockerService
    {
        /// <summary>
        /// Mengambil daftar seluruh drive yang terhubung beserta status BitLocker menggunakan manage-bde.exe
        /// </summary>
        public async Task<List<DriveInfoModel>> GetAllDrivesAsync()
        {
            var list = new List<DriveInfoModel>();
            var driveInfos = DriveInfo.GetDrives();

            foreach (var d in driveInfos)
            {
                if (!d.IsReady && d.DriveType != DriveType.Removable) continue;

                var letter = d.Name.TrimEnd('\\');
                var model = new DriveInfoModel
                {
                    Letter = letter,
                    VolumeLabel = d.IsReady ? (string.IsNullOrEmpty(d.VolumeLabel) ? "Local Disk" : d.VolumeLabel) : "Removable Disk",
                    DeviceType = MapDeviceType(d.DriveType),
                    TotalBytes = d.IsReady ? d.TotalSize : 0,
                    UsedBytes = d.IsReady ? (d.TotalSize - d.AvailableFreeSpace) : 0,
                    IsRemovable = d.DriveType == DriveType.Removable,
                    BitLockerStatus = "Memeriksa...",
                    LockStatus = "Unknown",
                    ProtectionStatus = "Unknown",
                    EncryptionMethod = "None"
                };

                // Ambil status BitLocker spesifik drive dari manage-bde -status <drive>
                await PopulateBitLockerStatusAsync(model);
                list.Add(model);
            }

            return list;
        }

        private async Task PopulateBitLockerStatusAsync(DriveInfoModel model)
        {
            var (output, exitCode) = await ExecuteManageBdeAsync($"-status {model.Letter}");
            if (exitCode != 0 || string.IsNullOrEmpty(output))
            {
                model.BitLockerStatus = "Tidak Terenkripsi (Off)";
                model.ProtectionStatus = "Protection Off";
                return;
            }

            // Parsing output manage-bde
            var lockMatch = Regex.Match(output, @"Lock Status:\s*(Locked|Unlocked)");
            if (lockMatch.Success) model.LockStatus = lockMatch.Groups[1].Value;

            var protMatch = Regex.Match(output, @"Protection Status:\s*(Protection [A-Za-z]+)");
            if (protMatch.Success) model.ProtectionStatus = protMatch.Groups[1].Value;

            var methodMatch = Regex.Match(output, @"Encryption Method:\s*([A-Za-z0-9\-]+)");
            if (methodMatch.Success) model.EncryptionMethod = methodMatch.Groups[1].Value;

            var pctMatch = Regex.Match(output, @"Percentage Encrypted:\s*([0-9\.]+)%");
            double pct = pctMatch.Success ? double.Parse(pctMatch.Groups[1].Value) : 0;

            var convMatch = Regex.Match(output, @"Conversion Status:\s*(.+)");
            string conv = convMatch.Success ? convMatch.Groups[1].Value.Trim() : "";

            if (conv.Contains("Decryption in Progress", StringComparison.OrdinalIgnoreCase))
            {
                model.BitLockerStatus = "Sedang Dekripsi";
                model.DecryptionPercent = 100 - pct;
            }
            else if (model.LockStatus == "Locked")
            {
                model.BitLockerStatus = "Terenkripsi (Terkunci)";
            }
            else if (model.ProtectionStatus == "Protection On")
            {
                model.BitLockerStatus = "Terenkripsi (Terbuka)";
            }
            else
            {
                model.BitLockerStatus = "Tidak Terenkripsi (Off)";
            }
        }

        /// <summary>
        /// Membuka kunci drive menggunakan Password: manage-bde -unlock E: -Password
        /// </summary>
        public async Task<(bool Success, string Message)> UnlockWithPasswordAsync(string driveLetter, string password)
        {
            var pinfo = new ProcessStartInfo
            {
                FileName = "manage-bde.exe",
                Arguments = $"-unlock {driveLetter} -Password",
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };

            using var process = new Process { StartInfo = pinfo };
            process.Start();

            // Kirim password ke stdin (aman dari logging command line Windows)
            await process.StandardInput.WriteLineAsync(password);
            await process.StandardInput.FlushAsync();

            string output = await process.StandardOutput.ReadToEndAsync();
            string error = await process.StandardError.ReadToEndAsync();
            await process.WaitForExitAsync();

            bool success = process.ExitCode == 0 && output.Contains("successfully unlocked", StringComparison.OrdinalIgnoreCase);
            return (success, success ? "Drive berhasil dibuka dengan Password." : (string.IsNullOrEmpty(error) ? output : error));
        }

        /// <summary>
        /// Membuka kunci drive menggunakan 48-digit Recovery Key: manage-bde -unlock E: -RecoveryPassword [KEY]
        /// </summary>
        public async Task<(bool Success, string Message)> UnlockWithRecoveryKeyAsync(string driveLetter, string recoveryKey)
        {
            var cleanKey = recoveryKey.Trim().Replace(" ", "");
            var (output, exitCode) = await ExecuteManageBdeAsync($"-unlock {driveLetter} -RecoveryPassword {cleanKey}");

            bool success = exitCode == 0 && output.Contains("successfully unlocked", StringComparison.OrdinalIgnoreCase);
            return (success, success ? "Drive berhasil dibuka dengan Recovery Key 48-digit." : output);
        }

        /// <summary>
        /// Menonaktifkan BitLocker dan memulai proses dekripsi: manage-bde -off E:
        /// </summary>
        public async Task<(bool Success, string Message)> DisableBitLockerAsync(string driveLetter)
        {
            var (output, exitCode) = await ExecuteManageBdeAsync($"-off {driveLetter}");
            bool success = exitCode == 0 || output.Contains("Decryption is now in progress", StringComparison.OrdinalIgnoreCase);
            return (success, output);
        }

        /// <summary>
        /// Menjeda proses dekripsi atau enkripsi: manage-bde -pause E:
        /// </summary>
        public async Task<(bool Success, string Message)> PauseBitLockerAsync(string driveLetter)
        {
            var (output, exitCode) = await ExecuteManageBdeAsync($"-pause {driveLetter}");
            return (exitCode == 0, output);
        }

        /// <summary>
        /// Melanjutkan proses dekripsi atau enkripsi: manage-bde -resume E:
        /// </summary>
        public async Task<(bool Success, string Message)> ResumeBitLockerAsync(string driveLetter)
        {
            var (output, exitCode) = await ExecuteManageBdeAsync($"-resume {driveLetter}");
            return (exitCode == 0, output);
        }

        private static async Task<(string Output, int ExitCode)> ExecuteManageBdeAsync(string arguments)
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "manage-bde.exe",
                    Arguments = arguments,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using var process = new Process { StartInfo = psi };
                process.Start();

                string stdout = await process.StandardOutput.ReadToEndAsync();
                string stderr = await process.StandardError.ReadToEndAsync();
                await process.WaitForExitAsync();

                return (string.IsNullOrWhiteSpace(stderr) ? stdout : $"{stdout}\n{stderr}", process.ExitCode);
            }
            catch (Exception ex)
            {
                return ($"Error mengeksekusi manage-bde: {ex.Message}", -1);
            }
        }

        private static string MapDeviceType(DriveType type) => type switch
        {
            DriveType.Removable => "USB Flashdisk",
            DriveType.Fixed => "Drive Internal / Eksternal",
            _ => "Storage Device"
        };
    }
}