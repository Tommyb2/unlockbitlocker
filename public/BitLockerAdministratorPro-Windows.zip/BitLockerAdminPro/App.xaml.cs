using System.Security.Principal;
using System.Windows;

namespace BitLockerAdminPro
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Verifikasi bahwa aplikasi berjalan dengan hak akses Administrator
            if (!IsAdministrator())
            {
                MessageBox.Show(
                    "BitLocker Administrator Pro memerlukan hak akses Administrator untuk mengelola BitLocker.\n\nSilakan klik kanan file .exe dan pilih 'Run as administrator'.",
                    "Akses Administrator Diperlukan",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );
            }
        }

        private static bool IsAdministrator()
        {
            using var identity = WindowsIdentity.GetCurrent();
            var principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }
    }
}