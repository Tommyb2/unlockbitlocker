@echo off
echo ==========================================================
echo   BitLocker Administrator Pro - Build Standalone .EXE
echo   Target: Windows 10 & Windows 11 (x64)
echo ==========================================================
echo.

where dotnet >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] .NET 8 SDK tidak ditemukan di komputer ini!
    echo Silakan install .NET 8 SDK dari https://dotnet.microsoft.com/download/dotnet/8.0
    pause
    exit /b 1
)

echo [1/3] Merestore dependensi NuGet...
dotnet restore

echo.
echo [2/3] Membangun aplikasi (.NET 8 WPF x64 Release)...
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o ./publish

if %ERRORLEVEL% equ 0 (
    echo.
    echo ==========================================================
    echo   [SUKSES] Build selesai!
    echo   File executable siap di:
    echo   %~dp0publish\BitLockerAdminPro.exe
    echo.
    echo   CATATAN: Jalankan file .exe dengan 'Run as Administrator'!
    echo ==========================================================
) else (
    echo.
    echo [ERROR] Build gagal. Periksa error di atas.
)

pause