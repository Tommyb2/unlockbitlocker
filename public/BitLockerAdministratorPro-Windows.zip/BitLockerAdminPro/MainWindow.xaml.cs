using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using BitLockerAdminPro.Models;
using BitLockerAdminPro.Services;

namespace BitLockerAdminPro
{
    public partial class MainWindow : Window
    {
        private readonly BitLockerService _bitLockerService;
        private readonly ObservableCollection<DriveInfoModel> _drives;
        private readonly DispatcherTimer _timer;

        public MainWindow()
        {
            InitializeComponent();
            _bitLockerService = new BitLockerService();
            _drives = new ObservableCollection<DriveInfoModel>();
            ListViewDrives.ItemsSource = _drives;

            // Timer untuk auto refresh progres dekripsi setiap 5 detik
            _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(5) };
            _timer.Tick += async (s, e) => await RefreshDrivesAsync();
            _timer.Start();

            Loaded += async (s, e) => await RefreshDrivesAsync();
        }

        private async System.Threading.Tasks.Task RefreshDrivesAsync()
        {
            try
            {
                var drives = await _bitLockerService.GetAllDrivesAsync();
                _drives.Clear();
                foreach (var d in drives)
                {
                    _drives.Add(d);
                }
                LogActivity("INFO", "Daftar drive berhasil diperbarui via manage-bde");
            }
            catch (Exception ex)
            {
                LogActivity("ERROR", $"Gagal memperbarui drive: {ex.Message}");
            }
        }

        private async void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            await RefreshDrivesAsync();
        }

        private async void BtnScanUsb_Click(object sender, RoutedEventArgs e)
        {
            LogActivity("INFO", "Memindai perangkat penyimpanan USB baru...");
            await RefreshDrivesAsync();
        }

        private void ListViewDrives_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ListViewDrives.SelectedItem is DriveInfoModel drive)
            {
                TxtSelectedDrive.Text = $"{drive.Letter} [{drive.VolumeLabel}] - {drive.BitLockerStatus}\nKapasitas: {drive.UsedSizeDisplay} / {drive.TotalSizeDisplay}";
                ProgressDecryption.Value = drive.DecryptionPercent;
                TxtProgressPct.Text = $"{drive.DecryptionPercent:0}% Selesai";
                BtnUnlock.IsEnabled = drive.LockStatus == "Locked";
                BtnDisable.IsEnabled = drive.BitLockerStatus.Contains("Terenkripsi");
            }
        }

        private async void BtnUnlock_Click(object sender, RoutedEventArgs e)
        {
            if (ListViewDrives.SelectedItem is not DriveInfoModel drive) return;

            // Prompt dialog untuk input password atau 48-digit recovery key
            var inputDialog = new UnlockDialog(drive.Letter);
            if (inputDialog.ShowDialog() == true)
            {
                LogActivity("COMMAND", $"Membuka kunci drive {drive.Letter}...");
                (bool success, string msg) = inputDialog.IsRecoveryKey
                    ? await _bitLockerService.UnlockWithRecoveryKeyAsync(drive.Letter, inputDialog.Credential)
                    : await _bitLockerService.UnlockWithPasswordAsync(drive.Letter, inputDialog.Credential);

                if (success)
                {
                    MessageBox.Show($"Drive {drive.Letter} berhasil dibuka!", "BitLocker Administrator Pro", MessageBoxButton.OK, MessageBoxImage.Information);
                    LogActivity("SUCCESS", $"Drive {drive.Letter} berhasil dibuka.");
                    await RefreshDrivesAsync();
                }
                else
                {
                    MessageBox.Show($"Gagal membuka kunci drive: {msg}", "Error BitLocker", MessageBoxButton.OK, MessageBoxImage.Error);
                    LogActivity("ERROR", $"Gagal membuka {drive.Letter}: {msg}");
                }
            }
        }

        private async void BtnDisable_Click(object sender, RoutedEventArgs e)
        {
            if (ListViewDrives.SelectedItem is not DriveInfoModel drive) return;

            // Konfirmasi keamanan wajib
            var res = MessageBox.Show(
                $"PERINGATAN KEAMANAN:\n\nAnda akan menonaktifkan proteksi BitLocker dan mendekripsi seluruh isi drive {drive.Letter} [{drive.VolumeLabel}].\n\nPastikan perangkat TETAP TERHUBUNG selama proses dekripsi berlangsung!\n\nLanjutkan proses dekripsi resmi Windows?",
                "Konfirmasi Dekripsi BitLocker",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning
            );

            if (res == MessageBoxResult.Yes)
            {
                LogActivity("COMMAND", $"manage-bde -off {drive.Letter}");
                var (success, msg) = await _bitLockerService.DisableBitLockerAsync(drive.Letter);
                if (success)
                {
                    MessageBox.Show($"Dekripsi pada drive {drive.Letter} telah dimulai. Pantau progres pada bar dekripsi.", "Dekripsi Berjalan", MessageBoxButton.OK, MessageBoxImage.Information);
                    LogActivity("SUCCESS", $"Dekripsi dimulai untuk {drive.Letter}: {msg}");
                    await RefreshDrivesAsync();
                }
                else
                {
                    MessageBox.Show($"Gagal memulai dekripsi: {msg}", "Error BitLocker", MessageBoxButton.OK, MessageBoxImage.Error);
                    LogActivity("ERROR", $"Gagal dekripsi {drive.Letter}: {msg}");
                }
            }
        }

        private async void BtnCheckStatus_Click(object sender, RoutedEventArgs e)
        {
            if (ListViewDrives.SelectedItem is not DriveInfoModel drive) return;
            LogActivity("COMMAND", $"manage-bde -status {drive.Letter}");
            // Memanggil service status
            await RefreshDrivesAsync();
        }

        private void LogActivity(string level, string message)
        {
            var line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [{level}] {message}\r\n";
            TxtConsoleLog.AppendText(line);
            TxtConsoleLog.ScrollToEnd();
        }
    }

    // Dialog form sederhana untuk Unlock
    public class UnlockDialog : Window
    {
        private readonly TextBox _txtInput = new() { Margin = new Thickness(0, 0, 0, 12), Height = 30 };
        private readonly RadioButton _rbPassword = new() { Content = "Password Pengguna", IsChecked = true, Margin = new Thickness(0, 0, 10, 0) };
        private readonly RadioButton _rbRecovery = new() { Content = "Recovery Key (48 Digit)", Margin = new Thickness(0, 0, 0, 10) };

        public string Credential => _txtInput.Text;
        public bool IsRecoveryKey => _rbRecovery.IsChecked == true;

        public UnlockDialog(string driveLetter)
        {
            Title = $"Buka Kunci Drive {driveLetter} - BitLocker";
            Width = 450;
            Height = 230;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background = System.Windows.Media.Brushes.Black;
            Foreground = System.Windows.Media.Brushes.White;

            var sp = new StackPanel { Margin = new Thickness(16) };
            sp.Children.Add(new TextBlock { Text = $"Masukkan Kredensial untuk Drive {driveLetter}:", Margin = new Thickness(0, 0, 0, 10), FontWeight = FontWeights.Bold });
            
            var rbPanel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 10) };
            rbPanel.Children.Add(_rbPassword);
            rbPanel.Children.Add(_rbRecovery);
            sp.Children.Add(rbPanel);

            sp.Children.Add(_txtInput);

            var btnPanel = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            var btnOk = new Button { Content = "Unlock Drive", Width = 110, Margin = new Thickness(0, 0, 8, 0) };
            btnOk.Click += (s, e) => { DialogResult = true; Close(); };
            var btnCancel = new Button { Content = "Batal", Width = 80 };
            btnCancel.Click += (s, e) => { DialogResult = false; Close(); };

            btnPanel.Children.Add(btnOk);
            btnPanel.Children.Add(btnCancel);
            sp.Children.Add(btnPanel);

            Content = sp;
        }
    }
}