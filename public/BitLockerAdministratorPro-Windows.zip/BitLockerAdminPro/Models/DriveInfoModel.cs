using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace BitLockerAdminPro.Models
{
    public class DriveInfoModel : INotifyPropertyChanged
    {
        private string _letter = "";
        private string _volumeLabel = "";
        private string _deviceType = "";
        private long _totalBytes;
        private long _usedBytes;
        private string _bitLockerStatus = "";
        private string _lockStatus = "";
        private string _protectionStatus = "";
        private string _encryptionMethod = "";
        private double _decryptionPercent;
        private bool _isRemovable;

        public string Letter
        {
            get => _letter;
            set { _letter = value; OnPropertyChanged(); }
        }

        public string VolumeLabel
        {
            get => _volumeLabel;
            set { _volumeLabel = value; OnPropertyChanged(); }
        }

        public string DeviceType
        {
            get => _deviceType;
            set { _deviceType = value; OnPropertyChanged(); }
        }

        public long TotalBytes
        {
            get => _totalBytes;
            set { _totalBytes = value; OnPropertyChanged(); OnPropertyChanged(nameof(TotalSizeDisplay)); }
        }

        public long UsedBytes
        {
            get => _usedBytes;
            set { _usedBytes = value; OnPropertyChanged(); OnPropertyChanged(nameof(UsedSizeDisplay)); OnPropertyChanged(nameof(UsagePercentage)); }
        }

        public string BitLockerStatus
        {
            get => _bitLockerStatus;
            set { _bitLockerStatus = value; OnPropertyChanged(); }
        }

        public string LockStatus
        {
            get => _lockStatus;
            set { _lockStatus = value; OnPropertyChanged(); }
        }

        public string ProtectionStatus
        {
            get => _protectionStatus;
            set { _protectionStatus = value; OnPropertyChanged(); }
        }

        public string EncryptionMethod
        {
            get => _encryptionMethod;
            set { _encryptionMethod = value; OnPropertyChanged(); }
        }

        public double DecryptionPercent
        {
            get => _decryptionPercent;
            set { _decryptionPercent = value; OnPropertyChanged(); }
        }

        public bool IsRemovable
        {
            get => _isRemovable;
            set { _isRemovable = value; OnPropertyChanged(); }
        }

        public string TotalSizeDisplay => FormatBytes(TotalBytes);
        public string UsedSizeDisplay => FormatBytes(UsedBytes);
        public double UsagePercentage => TotalBytes > 0 ? ((double)UsedBytes / TotalBytes) * 100 : 0;

        private static string FormatBytes(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB", "TB" };
            double len = bytes;
            int order = 0;
            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len /= 1024;
            }
            return $"{len:0.#} {sizes[order]}";
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}